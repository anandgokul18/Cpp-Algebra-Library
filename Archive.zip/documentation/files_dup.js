var files_dup =
[
    [ "algebralib.h", "algebralib_8h_source.html", null ],
    [ "matrix.h", "matrix_8h_source.html", null ]
];