var annotated_dup =
[
    [ "Matrix", "class_matrix.html", "class_matrix" ]
];