var searchData=
[
  ['operator_28_29_10',['operator()',['../class_matrix.html#a0660b3c38abf6f27bb632e29b103bfe2',1,'Matrix']]],
  ['operator_2a_11',['operator*',['../class_matrix.html#ad4f91888b70d99e9b865b2d9251e1c37',1,'Matrix::operator*(const Matrix &amp;) const'],['../class_matrix.html#ae9588d0a4bc385a01064b1fadc1464a6',1,'Matrix::operator*(const double &amp;) const']]],
  ['operator_3d_12',['operator=',['../class_matrix.html#ae3695797299c70849667c22a098db137',1,'Matrix']]]
];
