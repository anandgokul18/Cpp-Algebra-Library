var indexSectionsWithContent =
{
  0: "emopt",
  1: "m",
  2: "emopt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

