var searchData=
[
  ['matrix_1',['Matrix',['../class_matrix.html',1,'Matrix'],['../class_matrix.html#a8565cf8b48aa066a2470c53c3b7ccd73',1,'Matrix::Matrix()']]]
];
