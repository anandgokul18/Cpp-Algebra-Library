var searchData=
[
  ['equals_0',['equals',['../class_matrix.html#a21f3329634a3cd50e7fcc7098867142d',1,'Matrix']]]
];
