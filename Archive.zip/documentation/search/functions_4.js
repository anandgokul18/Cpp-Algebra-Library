var searchData=
[
  ['transpose_14',['transpose',['../class_matrix.html#a759661b75b9681f3a89ff75e27933b3a',1,'Matrix']]]
];
