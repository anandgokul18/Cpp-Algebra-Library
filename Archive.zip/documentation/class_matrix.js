var class_matrix =
[
    [ "Matrix", "class_matrix.html#a8565cf8b48aa066a2470c53c3b7ccd73", null ],
    [ "Matrix", "class_matrix.html#a0b9cfa2302a0273afb1b26e501f93abc", null ],
    [ "~Matrix", "class_matrix.html#a9b1c3627f573d78a2f08623fdfef990f", null ],
    [ "equals", "class_matrix.html#a21f3329634a3cd50e7fcc7098867142d", null ],
    [ "operator()", "class_matrix.html#a0660b3c38abf6f27bb632e29b103bfe2", null ],
    [ "operator*", "class_matrix.html#ae9588d0a4bc385a01064b1fadc1464a6", null ],
    [ "operator*", "class_matrix.html#ad4f91888b70d99e9b865b2d9251e1c37", null ],
    [ "operator=", "class_matrix.html#ae3695797299c70849667c22a098db137", null ],
    [ "print", "class_matrix.html#abad4f764e17de0076ecdd89ffd1dbf50", null ],
    [ "transpose", "class_matrix.html#a759661b75b9681f3a89ff75e27933b3a", null ],
    [ "m_col", "class_matrix.html#a0b8e4a62b440a5b5dc895a4b8daffc11", null ],
    [ "m_row", "class_matrix.html#a0bd93b4181c786dd0458d5ab96c9dab4", null ],
    [ "val", "class_matrix.html#ad62e40738fc972058595524003b6dca6", null ]
];